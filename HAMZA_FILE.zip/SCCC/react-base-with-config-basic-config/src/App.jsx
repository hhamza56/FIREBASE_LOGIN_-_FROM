import React from 'react'
import Signup from './pages/Signup'
import './App.css'
import { Router_App } from './config/Router_App'

const App = () => {
  return (
   <Router_App />
  )
}

export default App
