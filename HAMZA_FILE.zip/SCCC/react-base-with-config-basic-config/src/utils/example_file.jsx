const obj = {
    topic:'React',
    class:15,
}

obj.class = 16
obj['class'] = 16