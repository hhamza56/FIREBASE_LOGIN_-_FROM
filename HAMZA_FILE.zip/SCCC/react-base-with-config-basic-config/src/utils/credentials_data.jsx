const credentials_data = {
  username: "admin",
  password: "12345",
};

export { credentials_data };
